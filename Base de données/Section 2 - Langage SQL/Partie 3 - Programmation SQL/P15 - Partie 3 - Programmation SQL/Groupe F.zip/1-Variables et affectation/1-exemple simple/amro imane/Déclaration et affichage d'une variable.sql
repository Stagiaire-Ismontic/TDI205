Declare @var_1 int;
Declare @var_2 varchar(30);

select @var_1 as note ,@var_2 as nom;