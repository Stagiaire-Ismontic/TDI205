Declare @var_1 int;
Declare @var_2 varchar(30);

set @var_1=15;
set @var_2='madani';
 
select @var_1 as nbr ,@var_2 as nom;